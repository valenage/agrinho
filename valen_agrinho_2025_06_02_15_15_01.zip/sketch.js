let particles = []; 
let numParticles = 100;

function setup() {
  createCanvas(windowWidth, windowHeight); 
  for (let i = 0; i < numParticles; i++) {
    particles.push(new Particle(random(width), random(height)));
  }
}

function draw() {
  background(0, 0, 0, 10); 

  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];

    let mouseForce = p5.Vector.sub(createVector(mouseX, mouseY), p.position);
    mouseForce.normalize(); 
    mouseForce.mult(0.5); 
    if (mouseIsPressed) {
      mouseForce.mult(-1); 
    }
    p.applyForce(mouseForce);
    p.update();
    p.display();

    for (let j = i + 1; j < particles.length; j++) {
      let other = particles[j];
      let d = p.position.dist(other.position); 
      
      if (d < 100) { 
        let alpha = map(d, 0, 100, 255, 0); 
        stroke(255, alpha); 
        line(p.position.x, p.position.y, other.position.x, other.position.y);
      }
    }

   
  }
}

class Particle {
  constructor(x, y) {
    this.position = createVector(x, y); 
    this.velocity = p5.Vector.random2D(); 
    this.velocity.mult(random(0.5, 2)); 
    this.acceleration = createVector(0, 0); 
    this.mass = random(2, 5);
    this.radius = 4; 
    this.color = color(random(150, 255), random(150, 255), random(150, 255), 200);
  }
 
  applyForce(force) {
    let f = p5.Vector.div(force, this.mass); 
    this.acceleration.add(f);
  }
  update() {
    this.velocity.add(this.acceleration); 
    this.velocity.limit(5);
    this.position.add(this.velocity);
    this.acceleration.mult(0); 
  }

  display() {
    noStroke();
    fill(this.color);
    ellipse(this.position.x, this.position.y, this.radius * 2);
  }

  checkEdges() {
    if (this.position.x > width) {
      this.position.x = 0;
    } else if (this.position.x < 0) {
      this.position.x = width;
    }
    if (this.position.y > height) {
      this.position.y = 0;
    } else if (this.position.y < 0) {
      this.position.y = height;
    }
  }
}

// Função para redimensionar a tela se a janela for redimensionada
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}